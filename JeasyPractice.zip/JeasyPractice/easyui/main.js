$(document).ready(function() {

$('#rr').resizable({
    maxWidth:800,
    maxHeight:600
});
	
});